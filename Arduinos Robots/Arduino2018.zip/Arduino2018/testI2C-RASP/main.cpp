#include <iostream>
#include <unistd.h>
#include <wiringPi.h>
#include <wiringPiI2C.h>
#include <sys/time.h>

using namespace std;

///////////////////////////// PROGRAMME PRINCIPAL ///////////////////////////////
int main(int argc, char **argv) {
/***************************** Début du programme ******************************/
	cout << "Debut du programme" << endl;

	wiringPiSetupGpio();

	int i2c = wiringPiI2CSetup(9);
	if(i2c < 0)
		return 1;

	uint8_t data[1];
	int i = 1;
	data[0] = 1;
	while(1) {
		write(i2c, data, 1);
		cout << i << endl;
		i++;
		sleep(1);
	}

	close(i2c);

	cout << "Fin du programme" << endl;
}
